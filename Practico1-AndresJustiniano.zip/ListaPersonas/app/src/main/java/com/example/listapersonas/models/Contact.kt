package com.example.listapersonas.models

import android.graphics.Color

data class Contact(
    var phone: String,
    var backgroundColor: Int = Color.TRANSPARENT

)